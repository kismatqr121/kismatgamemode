# KismatGameMode (Fabric, Minecraft 1.21.11, server-side)

Commands (only the player `kismatrip1000`, case-insensitive, can use them):

- /creative, /gmc
- /survival, /gms
- /adventure, /gma
- /spectator, /gmsp, /inspector

Everyone else sees a red "You are not allowed to use this command."

## Build

Requires JDK 21 and internet access to maven.fabricmc.net.

    ./gradlew build          (Windows: gradlew.bat build)

The mod to install is `build/libs/kismatgamemode-1.0.0.jar`
(NOT the `-sources` jar). Put it in the server's `mods` folder together
with Fabric API 0.141.4+1.21.11 (or newer for 1.21.11).

## Version notes

Check https://fabricmc.net/develop/ for the newest Loom/Loader for 1.21.11 and
edit `gradle.properties` if needed (`loom_version`, `loader_version`).
