package com.kismat.gamemode;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;

public class KismatGameMode implements ModInitializer {
    /** Only this player may use the commands (compared case-insensitively). */
    private static final String ALLOWED_USERNAME = "kismatrip1000";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            register(dispatcher, GameType.CREATIVE, "creative", "gmc");
            register(dispatcher, GameType.SURVIVAL, "survival", "gms");
            register(dispatcher, GameType.ADVENTURE, "adventure", "gma");
            register(dispatcher, GameType.SPECTATOR, "spectator", "gmsp", "inspector");
        });
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher, GameType mode, String... names) {
        for (String name : names) {
            // No .requires(...) on purpose: the command is visible to everyone,
            // the username check happens inside the command.
            dispatcher.register(Commands.literal(name).executes(ctx -> run(ctx, mode)));
        }
    }

    private static int run(CommandContext<CommandSourceStack> ctx, GameType mode) {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayer();

        if (player == null || !ALLOWED_USERNAME.equalsIgnoreCase(player.getName().getString())) {
            source.sendFailure(Component.literal("You are not allowed to use this command.")
                    .withStyle(ChatFormatting.RED));
            return 0;
        }

        player.setGameMode(mode);
        player.sendSystemMessage(Component.literal("Your game mode is now " + mode.getName() + ".")
                .withStyle(ChatFormatting.GREEN));
        return 1;
    }
}
